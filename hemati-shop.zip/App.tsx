import React, { useState, useRef, useEffect } from 'react';
import { RecipeAssistant } from './components/RecipeAssistant';
import { ImageEditor } from './components/ImageEditor';
import { OnlineStore } from './components/OnlineStore';
import { AdminPanel } from './components/AdminPanel';
import { AppTab, CartItem, Product, StoreConfig } from './types';
import { getStoreConfig } from './services/dbService';
import { Store, ChefHat, Sparkles, ShoppingCart, LayoutDashboard, Menu, X, Phone, MapPin } from 'lucide-react';

// --- Animation Types & Components ---
interface FlyingItem {
  id: string;
  img: string;
  start: { x: number; y: number; w: number; h: number };
  end: { x: number; y: number };
}

const FlyingGraphic: React.FC<{ item: FlyingItem }> = ({ item }) => {
  const [style, setStyle] = useState<React.CSSProperties>({
    position: 'fixed',
    left: item.start.x,
    top: item.start.y,
    width: item.start.w,
    height: item.start.h,
    opacity: 1,
    zIndex: 9999,
    transition: 'all 0.6s cubic-bezier(0.2, 0.8, 0.2, 1)',
    backgroundImage: `url(${item.img})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    borderRadius: '0.75rem',
    pointerEvents: 'none',
    boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
  });

  useEffect(() => {
    // Force reflow and trigger animation
    requestAnimationFrame(() => {
      setStyle(prev => ({
        ...prev,
        left: item.end.x - 12, // Center align (24px/2)
        top: item.end.y - 12,
        width: 24,
        height: 24,
        opacity: 0,
        borderRadius: '50%',
        transform: 'scale(0.5)'
      }));
    });
  }, [item]);

  return <div style={style} className="border-2 border-white" />;
};

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.RECIPE);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [storeConfig, setStoreConfig] = useState<StoreConfig>({ address: '', phone: '' });
  
  // Animation State
  const [flyingItems, setFlyingItems] = useState<FlyingItem[]>([]);
  const cartRef = useRef<HTMLButtonElement>(null);

  // Load Store Config
  useEffect(() => {
    if (isSidebarOpen) {
      setStoreConfig(getStoreConfig());
    }
  }, [isSidebarOpen]);

  // Cart Logic
  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === productId) {
        const newQty = item.quantity + delta;
        return newQty > 0 ? { ...item, quantity: newQty } : item;
      }
      return item;
    }));
  };

  const clearCart = () => {
    setCart([]);
  };

  const handleFly = (rect: DOMRect, img: string) => {
    const cartRect = cartRef.current?.getBoundingClientRect();
    if (!cartRect) return;

    const end = { 
      x: cartRect.left + cartRect.width / 2, 
      y: cartRect.top + cartRect.height / 2 
    };

    const newItem = {
      id: Date.now().toString() + Math.random(),
      img,
      start: { x: rect.left, y: rect.top, w: rect.width, h: rect.height },
      end
    };

    setFlyingItems(prev => [...prev, newItem]);

    setTimeout(() => {
      setFlyingItems(prev => prev.filter(i => i.id !== newItem.id));
    }, 600);
  };

  return (
    <div className="flex flex-col h-screen bg-slate-50">
      {/* Animation Overlay */}
      {flyingItems.map(item => (
        <FlyingGraphic key={item.id} item={item} />
      ))}

      {/* Header */}
      <header className="bg-brand-blue text-white shadow-lg z-20 sticky top-0">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
             <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 hover:bg-white/10 rounded-full transition-colors"
            >
              <Menu className="w-6 h-6" />
            </button>
            <div className="bg-brand-yellow text-brand-blue p-2 rounded-lg shadow-md hidden sm:block">
              <Store className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">فروشگاه همتی</h1>
              <p className="text-xs text-blue-100 opacity-90 hidden xs:block">بهترین کیفیت، بهترین قیمت</p>
            </div>
          </div>
          <button 
            onClick={() => setActiveTab(AppTab.ADMIN)}
            className={`flex items-center gap-2 text-sm font-medium px-3 py-1.5 rounded-lg transition-colors ${
              activeTab === AppTab.ADMIN 
                ? 'bg-brand-yellow text-brand-blue shadow-inner' 
                : 'bg-white/10 hover:bg-white/20 text-white'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span className="hidden sm:inline">پنل مدیریت</span>
          </button>
        </div>
      </header>

      {/* Sidebar (Drawer) */}
      {isSidebarOpen && (
        <div className="fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity"
            onClick={() => setIsSidebarOpen(false)}
          ></div>
          
          {/* Sidebar Content */}
          <div className="relative bg-white w-80 max-w-[85vw] h-full shadow-2xl p-6 flex flex-col animate-fade-in-right">
            <button 
              onClick={() => setIsSidebarOpen(false)}
              className="absolute left-4 top-4 text-gray-400 hover:text-red-500 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="mt-8 mb-8 text-center">
              <div className="bg-brand-yellow w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg border-4 border-white">
                <Store className="text-brand-blue w-10 h-10" />
              </div>
              <h2 className="text-2xl font-bold text-brand-blue">فروشگاه همتی</h2>
              <p className="text-gray-500 text-sm mt-1">همیشه تازه، همیشه ارزان</p>
            </div>

            <div className="space-y-6 flex-1 overflow-y-auto">
              <div>
                <h3 className="font-bold text-gray-800 mb-3 border-b pb-2 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-brand-blue" />
                  آدرس فروشگاه
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  {storeConfig.address || 'در حال بارگذاری...'}
                </p>
              </div>

              <div>
                <h3 className="font-bold text-gray-800 mb-3 border-b pb-2 flex items-center gap-2">
                  <Phone className="w-5 h-5 text-brand-blue" />
                  ارتباط با ما
                </h3>
                <div className="space-y-3">
                  <a href={`tel:${storeConfig.phone}`} className="flex items-center gap-3 text-gray-600 hover:text-brand-blue transition-colors">
                    <span className="font-mono text-lg font-bold">{storeConfig.phone || '---'}</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 overflow-hidden relative">
        {activeTab === AppTab.RECIPE && (
          <RecipeAssistant 
            addToCart={addToCart} 
            onGoToStore={() => setActiveTab(AppTab.STORE)}
            onFly={handleFly}
          />
        )}
        {activeTab === AppTab.SMART_ROOM && <ImageEditor />}
        {activeTab === AppTab.STORE && (
          <OnlineStore 
            cart={cart}
            addToCart={addToCart}
            removeFromCart={removeFromCart}
            updateQuantity={updateQuantity}
            clearCart={clearCart}
            onFly={handleFly}
          />
        )}
        {activeTab === AppTab.ADMIN && <AdminPanel />}
      </main>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t border-gray-200 fixed bottom-0 left-0 right-0 z-30 pb-safe shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)]">
        <div className="max-w-md mx-auto flex justify-around">
          <button
            onClick={() => setActiveTab(AppTab.RECIPE)}
            className={`flex flex-col items-center justify-center p-3 w-full transition-all ${
              activeTab === AppTab.RECIPE 
                ? 'text-brand-blue bg-blue-50 border-t-2 border-brand-blue' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <ChefHat className={`w-6 h-6 mb-1 ${activeTab === AppTab.RECIPE ? 'fill-current' : ''}`} />
            <span className="text-xs font-medium">آشپز هوشمند</span>
          </button>
          
          <button
            ref={cartRef}
            onClick={() => setActiveTab(AppTab.STORE)}
            className={`flex flex-col items-center justify-center p-3 w-full transition-all ${
              activeTab === AppTab.STORE 
                ? 'text-green-600 bg-green-50 border-t-2 border-green-600' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <div className="relative">
              <ShoppingCart className={`w-6 h-6 mb-1 ${activeTab === AppTab.STORE ? 'fill-current' : ''}`} />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-2 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center shadow-sm">
                  {cart.reduce((acc, item) => acc + item.quantity, 0)}
                </span>
              )}
            </div>
            <span className="text-xs font-medium">سفارش آنلاین</span>
          </button>

          <button
            onClick={() => setActiveTab(AppTab.SMART_ROOM)}
            className={`flex flex-col items-center justify-center p-3 w-full transition-all ${
              activeTab === AppTab.SMART_ROOM 
                ? 'text-purple-600 bg-purple-50 border-t-2 border-purple-600' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <Sparkles className={`w-6 h-6 mb-1 ${activeTab === AppTab.SMART_ROOM ? 'fill-current' : ''}`} />
            <span className="text-xs font-medium">اتاق هوشمند</span>
          </button>
        </div>
      </nav>
    </div>
  );
};