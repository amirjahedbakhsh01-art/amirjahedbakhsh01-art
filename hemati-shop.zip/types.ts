export interface Ingredient {
  name: string;
  amount: string;
  category: string;
}

export interface RecipeResponse {
  dishName: string;
  ingredients: Ingredient[];
  instructions: string[];
  cookingTime: string;
}

export enum AppTab {
  RECIPE = 'RECIPE',
  SMART_ROOM = 'SMART_ROOM',
  STORE = 'STORE',
  ADMIN = 'ADMIN',
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string | RecipeResponse;
  type: 'text' | 'recipe';
}

// --- Online Store Types ---

export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  image: string;
  unit: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export type OrderStatus = 'PENDING' | 'SHIPPED' | 'COMPLETED' | 'CANCELLED';

export interface Order {
  id: string;
  customerName: string;
  address: string;
  phone: string;
  items: CartItem[];
  totalAmount: number;
  status: OrderStatus;
  createdAt: string;
}

export interface StoreConfig {
  address: string;
  phone: string;
}